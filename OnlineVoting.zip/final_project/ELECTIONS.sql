CREATE DATABASE final;
USE final;

-- 1.Users Table
CREATE TABLE users (
    user_id VARCHAR(30) PRIMARY KEY, 
    full_name VARCHAR(100) NOT NULL,
    gender ENUM('male', 'female') NOT NULL,
    faculty_id VARCHAR(30) NOT NULL,
    is_resident TINYINT(1) NOT NULL,
    is_special_needs TINYINT(1) NOT NULL,   -- 1 for YES, 0 for NO
    is_international TINYINT(1) NOT NULL,    
    access_number VARCHAR(30) UNIQUE NOT NULL,  -- e.g. B2000
    role ENUM('voter', 'candidate', 'administrator') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) ON DELETE CASCADE
);

--ROLES
SHOW COLUMNS FROM users LIKE 'role';


-- 2.Faculty Table
CREATE TABLE faculty (
    faculty_id VARCHAR(30) PRIMARY KEY, 
    faculty_name VARCHAR(100) NOT NULL UNIQUE
);


--3. Posts Table
CREATE TABLE posts (
    post_id VARCHAR(30) PRIMARY KEY, --P%
    post_name VARCHAR(100) NOT NULL UNIQUE,
    requirements TEXT,
    semesters_left INT NOT NULL 
);

-- 4.Nomination Table
CREATE TABLE nominations (
    nomination_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(30) NOT NULL,
    post_id VARCHAR(30) NOT NULL,
    faculty_id VARCHAR(30),
    nomination_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (post_id) REFERENCES posts(post_id) ON DELETE CASCADE,
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) ON DELETE CASCADE
);

-- 5.Payments Table
CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    candidate_id VARCHAR(30) NOT NULL,
    post_id VARCHAR(30) NOT NULL,
    amount_paid DECIMAL(10, 2) NOT NULL CHECK (amount_paid >= 0),
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (candidate_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (post_id) REFERENCES posts(post_id) ON DELETE CASCADE
);


-- 6.Vetting Table
CREATE TABLE vetting (
    vetting_id VARCHAR(30) PRIMARY KEY,
    candidate_id VARCHAR(30) NOT NULL,
    post_id VARCHAR(30) NOT NULL,
    is_vetted TINYINT(1) DEFAULT 0, 
    vetted_by VARCHAR(30),
    vetting_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (candidate_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (post_id) REFERENCES posts(post_id) ON DELETE CASCADE,
    FOREIGN KEY (vetted_by) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Before inserT trigger to ensure only admins vet
DELIMITER /

CREATE TRIGGER vetting_admin_check
BEFORE INSERT ON vetting
FOR EACH ROW
BEGIN
  DECLARE vetter_role VARCHAR(20);

  SELECT role INTO vetter_role
  FROM users
  WHERE user_id = NEW.vetted_by;

  IF vetter_role <> 'administrator' THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Only administrators can vet candidates.';
  END IF;
END;

DELIMITER;

-- TESTING THE TRIGGER
INSERT INTO vetting (candidate_id, vetted_by)
VALUES ('U004', 'U002');


--7.Voters Table
CREATE TABLE voters (
    voter_id VARCHAR(30) PRIMARY KEY, 
    user_id VARCHAR(30) NOT NULL,
    post_id VARCHAR(30) NOT NULL,
    vote_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (post_id) REFERENCES posts(post_id) ON DELETE CASCADE
);

-- 8.Votes Table
CREATE TABLE votes (
    vote_id INT AUTO_INCREMENT PRIMARY KEY, 
    voter_id VARCHAR(30) NOT NULL,
    candidate_id VARCHAR(30) NOT NULL,
    post_id VARCHAR(30) NOT NULL,
    vote_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (voter_id) REFERENCES voters(voter_id) ON DELETE CASCADE,
    FOREIGN KEY (candidate_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (post_id) REFERENCES posts(post_id) ON DELETE CASCADE
);



-- 9.Results Table
CREATE TABLE results (
    result_id VARCHAR(30) PRIMARY KEY, 
    post_id VARCHAR(30) NOT NULL,
    candidate_id VARCHAR(30) NOT NULL,
    is_winner TINYINT(1) DEFAULT 0, -- 1 REPRESENTS WINNERS
    result_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES posts(post_id) ON DELETE CASCADE,
    FOREIGN KEY (candidate_id) REFERENCES users(user_id) ON DELETE CASCADE
);

INSERT INTO faculty (faculty_id, faculty_name)
VALUES 
('F001', 'Social Science'),
('F002', 'Engineering'),
('F003', 'Agriculture'),
('F004', 'Business'),
('F005', 'Law');

select * from faculty;


INSERT INTO users (user_id, full_name, gender, faculty_id, is_resident, is_special_needs, is_international, access_number, role)
VALUES
('U001', 'Ade Amos', 'male', 'F001', 1, 0, 0, 'B2001', 'voter'),
('U002', 'Mwine Tessy', 'female', 'F002', 0, 1, 1, 'B2002', 'candidate'),
('U003', 'Akampa Eliz', 'female', 'F003', 1, 0, 0, 'B2003', 'administrator'),
('U004', 'Manzi Ryan', 'male', 'F002', 0, 1, 1, 'B2004', 'voter'),
('U005', 'Nkunda Perez', 'female', 'F001', 1, 0, 0, 'B2005', 'candidate');

select * from users;


INSERT INTO posts (post_id, post_name, requirements, semesters_left)
VALUES
('P001', 'Guild President', 'Leadership experience', 4),
('P002', 'MP LAW', 'must belong to faculty of law', 3),
('P003', 'MP RESIDENTS MALE', 'must be a male resident', 2),
('P004', 'MP INTERNATIONAL STUDENTS', 'must be an international student', 2),
('P005', 'MP ENGINEERING', 'must belong to faculty of engineering', 2);

select * from posts;


DELIMITER /

--  A STORED PROCEDURE TO ADD NEW POSTS
CREATE PROCEDURE add_new_post(
    IN new_post_id varchar(30),
    IN new_post_name VARCHAR(100),
    IN new_requirements TEXT,
    IN new_semesters_left INT
)
BEGIN
    INSERT INTO posts (post_id, post_name, requirements, semesters_left)
    VALUES (new_post_id, new_post_name, new_requirements, new_semesters_left);
END /

DELIMITER;

--CALLING THE PROCEDURE
CALL add_new_post('P006', 'MP AGRICULTURE', 'must belong to the faculty of agriculture', 2);

select * from posts;


INSERT INTO nominations (user_id, post_id, faculty_id)
VALUES
('U002', 'P001', 'F002'),
('U005', 'P002', 'F005'),
('U001', 'P004', 'F002'),
('U004', 'P003', 'F001');


INSERT INTO payments (candidate_id, post_id, amount_paid)
VALUES
('U002', 'P001', 100000),
('U005', 'P002', 50000),
('U001', 'P004', 0),
('U004', 'P003', 50000);


INSERT INTO vetting (vetting_id, candidate_id, post_id, is_vetted, vetted_by)
VALUES
('VET001', 'U002', 'P001', 1, 'U003'),
('VET002', 'U005', 'P002', 1, 'U003'),
('VET003', 'U001', 'P004', 0, 'U003'),
('VET004', 'U004', 'P003', 1, 'U003');


INSERT INTO voters (voter_id, user_id, post_id)
VALUES('V001', 'U001', 'P001'),
('V002', 'U004', 'P003'),
('V003', 'U001', 'P005'),
('V004', 'U004', 'P002'),
('V005', 'U001', 'P004');

select * from voters;

INSERT INTO votes (voter_id, candidate_id, post_id)
VALUES('V001', 'U002', 'P001'),
('V002', 'U005', 'P002');

select * from votes;


select * from results;


DELIMITER /
--PROCEDURE TO ADD NEW USERS
CREATE PROCEDURE AddUser(IN p_user_id VARCHAR(30),
    IN p_full_name VARCHAR(100),
    IN p_gender ENUM('male', 'female'),
    IN p_faculty_id VARCHAR(30),
    IN p_is_resident TINYINT(1),
    IN p_is_special_needs TINYINT(1),
    IN p_is_international TINYINT(1),
    IN p_access_number VARCHAR(30),
    IN p_role ENUM('voter', 'candidate', 'administrator')
    )    
BEGIN
    INSERT INTO users (user_id, full_name, gender, faculty_id, is_resident, is_special_needs, is_international, access_number, role, created_at)
    VALUES (p_user_id, p_full_name, p_gender, p_faculty_id, p_is_resident, p_is_special_needs, p_is_international, p_access_number, p_role, CURRENT_TIMESTAMP());
END/

DELIMITER;


--CALLING THE PROCEDURE
CALL AddUser('U007', 'Commander Triga', 'male', 'F001', 1, 0, 0, 'B2007', 'voter');


--PROCEDURE TO ADD A VOTER
DELIMITER /

CREATE PROCEDURE AddVoter(
    IN p_voter_id VARCHAR(30),
    IN p_user_id VARCHAR(30),
    IN p_post_id VARCHAR(30)
)
BEGIN
    INSERT INTO voters (voter_id, user_id, post_id, vote_time)
    VALUES (p_voter_id, p_user_id, p_post_id, CURRENT_TIMESTAMP());
END /

DELIMITER ;

--CALLING THE PROCEDURE
INSERT INTO users (user_id, full_name, gender, faculty_id, is_resident, is_special_needs, is_international, access_number, role)
VALUES ('U009', 'Magezi Bright', 'male', 'F001', 1, 0, 0, 'B2009', 'voter');





--PROCEDURE TO ADD VOTES and making sure voters vote once
DELIMITER /

CREATE PROCEDURE AddVote(
    IN p_voter_id VARCHAR(30),
    IN p_candidate_id VARCHAR(30),
    IN p_post_id VARCHAR(30)
)
BEGIN
    -- Check if the voter has already voted for this post
    IF EXISTS (
        SELECT 1 
        FROM votes 
        WHERE voter_id = p_voter_id AND post_id = p_post_id
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Voter has already voted for this post.';
    ELSE
        -- Insert the vote
        INSERT INTO votes (voter_id, candidate_id, post_id, vote_time)
        VALUES (p_voter_id, p_candidate_id, p_post_id, CURRENT_TIMESTAMP());
    END IF;
END /

DELIMITER ;


--calling the AddVote procedure
CALL AddVote('V008', 'U008', 'P001');

CALL AddVote('V008', 'U008', 'P001');


--  Updating a faculty name
UPDATE faculty
SET faculty_name = 'Engineering and Technology'
WHERE faculty_id = 'F002';


--  Finding  the faculty with the most users
SELECT faculty.faculty_name, COUNT(users.user_id) AS user_count
FROM faculty
LEFT JOIN users ON faculty.faculty_id = users.faculty_id
GROUP BY faculty.faculty_name
ORDER BY user_count DESC;



DELIMITER /

CREATE TRIGGER declare_candidates_before_insert
BEFORE INSERT ON results
FOR EACH ROW
BEGIN
    DECLARE is_nominated INT;
    DECLARE is_vetted INT;

    -- Check if the candidate has been nominated for the specific post
    SELECT COUNT(*) INTO is_nominated
    FROM nominations 
    WHERE user_id = NEW.candidate_id AND post_id = NEW.post_id;

    -- Check if the candidate has passed vetting for the specific post
    SELECT is_vetted INTO is_vetted
    FROM vetting
    WHERE candidate_id = NEW.candidate_id AND post_id = NEW.post_id;

    -- Ensure that the candidate is both nominated and vetted
    IF is_nominated = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Candidate has not been nominated for this post.';
    END IF;

    IF is_vetted <> 1 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Candidate has not passed vetting for this post.';
    END IF;
END /

DELIMITER ;


-- Inserting a result for 2 who has been nominated and vetted for P001
INSERT INTO results (result_id, post_id, candidate_id, is_winner)
VALUES ('R9', 'P001', 'U002', 1);

-- Trying to insert result for U004 who has not been nominated for P001
INSERT INTO results (result_id, post_id, candidate_id, is_winner)
VALUES ('R6', 'P001', 'U004', 1);

select * from results;

DELETE FROM results
WHERE result_id = 'R002'


-- Create a View for Automatic Vote Counting
CREATE VIEW vote_results AS
SELECT 
    p.post_id,
    v.candidate_id,
    COUNT(v.vote_id) AS total_votes
FROM 
    posts p
JOIN 
    votes v ON p.post_id = v.post_id
GROUP BY 
    p.post_id, v.candidate_id;

select * from vote_results;


-- DECLARING WINNERS
SELECT 
    post_id,
    candidate_id AS winner_id,
    total_votes
FROM 
    vote_results
WHERE 
    total_votes = (
        SELECT MAX(total_votes)
        FROM vote_results AS subquery
        WHERE subquery.post_id = vote_results.post_id
    );


--- SECURITY AND USERS
--ADMIN
CREATE USER 'admin'@'%' IDENTIFIED BY 'admin@changemenow';
GRANT ALL PRIVILEGES ON *.* TO 'admin'@'%';
FLUSH PRIVILEGES;


-- CANDIDATES
CREATE USER 'candidates'@'%' IDENTIFIED BY 'changemenow@2025';
GRANT SELECT, INSERT ON final.votes TO 'candidates'@'%';
FLUSH PRIVILEGES;


--VOTERS
CREATE USER 'voters'@'%' IDENTIFIED BY 'changemenow@2000';
GRANT SELECT, INSERT ON final.votes TO 'voters'@'%';
FLUSH PRIVILEGES;


use final;






































